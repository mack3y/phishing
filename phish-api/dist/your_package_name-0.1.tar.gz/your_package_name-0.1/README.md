# PhishGuardian-API
This is server side code for our project PhishGuardian. It contains flask server code and some web scraping code.
